import connexion
import six

from swagger_server import util


def qs_get(sosendpoint, begin, end, parameter, site, windowwidth=None, windowinterval=None):  # noqa: E501
    """Retrieve a parameter from one station from start to end

     # noqa: E501

    :param sosendpoint: 
    :type sosendpoint: str
    :param begin: 
    :type begin: str
    :param end: 
    :type end: str
    :param parameter: 
    :type parameter: List[str]
    :param site: 
    :type site: List[str]
    :param windowwidth: 
    :type windowwidth: int
    :param windowinterval: 
    :type windowinterval: int

    :rtype: str
    """
    begin = util.deserialize_datetime(begin)
    end = util.deserialize_datetime(end)
    return 'do some magic!'


def qs_post(repourl, windowwidth=None, windowinterval=None):  # noqa: E501
    """Perform outlier analysis on file(s) stored in remote repo

     # noqa: E501

    :param repourl: 
    :type repourl: str
    :param windowwidth: 
    :type windowwidth: int
    :param windowinterval: 
    :type windowinterval: int

    :rtype: str
    """
    return 'do some magic!'
